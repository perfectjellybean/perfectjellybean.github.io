import sys
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin

import requests
from bs4 import BeautifulSoup as bs
import resolveurl
import re

__url__ = sys.argv[0]
__handle__ = int(sys.argv[1])

SITE_URL = "https://myrunningman.com/"
SITE_EPISODES_URL = "https://myrunningman.com/episodes"
SITE_EPISODE_URL = "https://myrunningman.com/ep/"

SITE_EPISODE_THUMBNAIL = "https://www.myrunningman.com/assets/epimg/"

FEMBED_VIDEO_BASE_URL = "https://www.fembed.com/v/" 
VIDLOX_VIDEO_BASE_URL = "https://www.vidlox.me/embed-" 

def get_html(url):
    page = requests.get(url)
    html = bs(page.text, 'html5lib')

    return html

def get_categories():
    categories = ["Episodes"]

    

    return categories

def get_episodes(category):
    episodes = []

    html = get_html(SITE_EPISODES_URL)
    h1 = html.find("h1").getText().encode("utf8")
    episode_count = int(re.search("\(([^)]+)", h1).group(1))

    for episode_number in range(episode_count, 0, -1):
        episodes.append({"title": "Episode " + str(episode_number), "link": SITE_EPISODE_URL + str(episode_number)})
        
    return episodes

def get_episode(url):
    episode = {'links': [], 'host': []}

    html = get_html(url)

    title = html.select_one("h1").text
    stream_ids = html.findAll('a', {'data-url': True})
    # stream_hosts = html.findAll('span', {'class': ['label-info', 'label-success'], 'title': True})

    episode['title'] = title
    episode['number'] = re.search('\d+', title).group()
    
    for i in range(0, len(stream_ids)):
        if stream_ids[i]['data-url'][0] == 'f':
            episode['links'].append(FEMBED_VIDEO_BASE_URL + stream_ids[i]['data-url'][1:])
            episode['host'].append('fembed')
        if stream_ids[i]['data-url'][0] == 'v':
            episode['links'].append(VIDLOX_VIDEO_BASE_URL + stream_ids[i]['data-url'][1:])
            episode['host'].append('vidlox')

    return episode

def list_categories():
    categories = get_categories()
    listing = []

    for category in categories:
        list_item = xbmcgui.ListItem(label=category)
        url = "{0}?action=listing&category={1}".format(__url__, category)
        is_folder = True
        listing.append((url, list_item, is_folder))

    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)

def list_episodes(category):
    episodes = get_episodes(category)
    listing = []
    
    for episode in episodes:
        list_item = xbmcgui.ListItem(label=episode["title"])
        list_item.setInfo("video", {"title": episode["title"]})
        list_item.setProperty("isPlayable", "false")
        url = "{0}?action=open&link={1}".format(__url__, episode['link'])
        is_folder = True
        listing.append((url, list_item, is_folder))
    
    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)

def exists(url):
    r = requests.head(url)
    return r.status_code == requests.codes.ok

def list_episode(url):
    episode = get_episode(url)
    listing = []

    thumbnail_image = SITE_EPISODE_THUMBNAIL + episode['number'] + '.jpg'

    if not exists(thumbnail_image):
        thumbnail_image = SITE_EPISODE_THUMBNAIL + episode['number'] + '_temp.jpg'

    i = 0
    for link in episode['links']:
        list_item = xbmcgui.ListItem(label=episode["host"][i], thumbnailImage=thumbnail_image)
        list_item.setInfo("video", {"title": episode["title"], "plot": episode['title']})
        list_item.setProperty("isPlayable", "true")
        url = "{0}?action=play&link={1}".format(__url__, link)
        is_folder = False
        listing.append((url, list_item, is_folder))
        i+=1
    
    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)

def play_episode(path):
    hmf = resolveurl.HostedMediaFile(path).resolve()
    play_item = xbmcgui.ListItem(path=hmf)
    
    xbmcplugin.setResolvedUrl(__handle__, True, listitem=play_item)

def router(paramstring):
    params = dict(parse_qsl(paramstring[1:]))
 
    if params:
        if params['action'] == 'listing':
            list_episodes(params['category'])
        elif params['action'] == 'open':
            list_episode(params['link'])
        elif params['action'] == 'play':
            play_episode(params['link'])
    else:
        list_categories()

if __name__ == "__main__":
    router(sys.argv[2])