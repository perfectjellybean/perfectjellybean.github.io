import sys
from urllib.parse import parse_qsl, urljoin

import xbmcgui
import xbmcplugin

import requests
from bs4 import BeautifulSoup as bs
import resolveurl
import re
import math

__url__ = sys.argv[0]
__handle__ = int(sys.argv[1])

SITE_URL = "https://myrunningman.com/"
SITE_EPISODES_URL = "https://myrunningman.com/episodes"
SITE_EPISODE_URL = "https://myrunningman.com/ep/"
SITE_GUESTS_URL = "https://www.myrunningman.com/guests"
SITE_GUEST_URL = "https://www.myrunningman.com/guest/"
SITE_TAGS_URL = "https://www.myrunningman.com/tags"
SITE_TAG_URL = "https://www.myrunningman.com/tag/"

SITE_EPISODE_THUMBNAIL = "https://www.myrunningman.com/assets/epimg/"

FEMBED_VIDEO_BASE_URL = "https://www.fembed.com/v/" 
VIDLOX_VIDEO_BASE_URL = "https://www.vidlox.me/embed-" 

def get_html(url):
    page = requests.get(url)
    html = bs(page.text, 'html5lib')

    return html

def get_categories():
    categories = ["Episodes", "Tags", "Guests"]

    return categories

def get_listing(category):
    if category == "Episodes":
        list_episodes(category)
    elif category == "Tags":
        list_tags(category)
    elif category == "Guests":
        list_guests(category)

def get_episodes(category):
    episodes = []

    html = get_html(SITE_EPISODES_URL)
    h1 = html.find("h1").getText().encode("utf8")

    episode_count = int(re.search("\(([^)]+)", str(h1)).group(1))

    for episode_number in range(episode_count, 0, -1):
        episodes.append({"title": "Episode " + str(episode_number), "link": SITE_EPISODE_URL + str(episode_number)})
        
    return episodes

def get_tags(category):
    tags = []

    html = get_html(SITE_TAGS_URL)
    tr = html.find("table").find("tbody").findAll("tr")

    for row in tr:
        td = row.findAll("td")        
        name = td[0].getText()   
        amount = int(td[1].getText())
        title = f"{name} - {amount}"
        link = SITE_TAG_URL + name
        tags.append({"title": title , "name": name, "amount": amount, "link": link })

    return tags

def get_guests():
    guests = []

    html = get_html(SITE_GUESTS_URL)
    tr = html.find("table").find("tbody").findAll("tr")

    for row in tr:
        td = row.findAll("td")        
        name = td[0].getText()
        href = td[0].find("a")['href']
        amount = int(td[3].getText())
        title = f"{name} - {amount}"
        link = urljoin(SITE_GUEST_URL, href)
        guests.append({"title": title , "name": name, "amount": amount, "link": link })

    return guests

def get_tag_episodes(url):
    episodes = []

    html = get_html(url)
    tr = html.find("table").find("tbody").findAll("tr")

    td = []
    for row in tr:
        td.append(row.findAll("td")[1])
        
    for item in td:
        p = item.find_all("p")
        title = f"""Episode {p[0].getText()[1:]}"""
        a = item.find("p").find("a")["href"]
        episode_number = a.split("/")[-1]
        link = urljoin(SITE_URL, a)

        guests = p[3].getText().split("  ")
        guests_str = " | ".join(guests)
        tags = p[4].getText().split("  ")
        tags_str = " | ".join(tags)

        img_src = item.find_previous_sibling("td").find("img")["src"]
        thumbnail_image = urljoin(SITE_URL, img_src)

        episodes.append({"title": title, "link": link, "thumbnail_image": thumbnail_image})

    nav = html.find("div", {"class": "container"}).find("div", {"class": "text-center"}).find("nav")
    if not nav is None:
        pagination = nav.find("ul", {"class": "pagination"})
        li = pagination.findAll("li")

        
        next_page = li[-1].find('a')
        if next_page:
            href = next_page['href']
            next_page_number = href[-1]
            title = f"""Page {next_page_number}"""
            link = urljoin(SITE_URL, next_page['href'])
            episodes.append({"page": True, "title": title, "link": link, "thumbnail_image": ""})

    return episodes

def get_guest_episodes(url):
    episodes = []

    html = get_html(url)
    episode_amount = int(re.search(r"\d+", html.find("h2").getText()).group())
    num_of_rows = math.ceil(episode_amount/4)
    rows = html.find("div", {"class": "container"}).findAll("div", {"class": "row"})[0:num_of_rows]

    divs = []
    for row in rows:
        divs.extend(row.findAll("div", {"class": "col-xs-12"}))
    
    for heading in divs:
        title = heading.find("h4").getText()[1:]
        a = heading.find("h4").find("a")["href"]
        img_src = heading.find("h4").find_next_sibling("a").find("img")["src"]
        thumbnail_image = urljoin(SITE_URL, img_src)
        link = urljoin(SITE_URL, a)
            
        episodes.append({"title": title, "link": link, "thumbnail_image": thumbnail_image})
        
    return episodes

def get_episode(url):
    episode = {'links': [], 'host': []}

    html = get_html(url)

    title = html.select_one("h1").text
    img_src = html.find("body").find("div", {"class": "container"}).find("div", {"class": "row"}).find("div").find("p").find("img")["src"]
    thumbnail_image = urljoin(SITE_URL, img_src)
    stream_ids = html.findAll('a', {'data-url': True})
    
    # stream_hosts = html.findAll('span', {'class': ['label-info', 'label-success'], 'title': True})

    episode['title'] = title
    episode['number'] = re.search('\d+', title).group()
    episode['thumbnail_image'] = thumbnail_image
    
    for i in range(0, len(stream_ids)):
        if stream_ids[i]['data-url'][0] == 'f':
            episode['links'].append(FEMBED_VIDEO_BASE_URL + stream_ids[i]['data-url'][1:])
            episode['host'].append('fembed')
        if stream_ids[i]['data-url'][0] == 'v':
            episode['links'].append(VIDLOX_VIDEO_BASE_URL + stream_ids[i]['data-url'][1:])
            episode['host'].append('vidlox')

    return episode

def list_categories():
    categories = get_categories()
    listing = []

    for category in categories:
        list_item = xbmcgui.ListItem(label=category)
        url = "{0}?action=listing&category={1}".format(__url__, category)
        is_folder = True
        listing.append((url, list_item, is_folder))

    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)

def list_episodes(category):
    episodes = get_episodes(category)
    listing = []
    
    for episode in episodes:
        list_item = xbmcgui.ListItem(label=episode["title"])
        list_item.setInfo("video", {"title": episode["title"]})
        list_item.setProperty("isPlayable", "false")
        url = "{0}?action=open&link={1}".format(__url__, episode['link'])
        is_folder = True
        listing.append((url, list_item, is_folder))
    
    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)

def list_tags(category):
    tags = get_tags(category)
    listing = []
    
    for tag in tags:
        list_item = xbmcgui.ListItem(label=tag["title"])
        list_item.setInfo("video", {"title": tag["title"]})
        list_item.setProperty("isPlayable", "false")
        url = "{0}?action=open_tag&link={1}".format(__url__, tag['link'])
        is_folder = True
        listing.append((url, list_item, is_folder))
    
    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)

def list_tag(url):
    episodes = get_tag_episodes(url)
    listing = []
    
    for episode in episodes:
        list_item = xbmcgui.ListItem(label=episode["title"])
        list_item.setArt({"thumb": episode["thumbnail_image"]})
        list_item.setInfo("video", {"title": episode["title"]})
        list_item.setProperty("isPlayable", "false")
        if "page" in episode:
            url = "{0}?action=open_next_page&link={1}".format(__url__, episode['link'])
        else:
            url = "{0}?action=open&link={1}".format(__url__, episode['link'])
        is_folder = True
        listing.append((url, list_item, is_folder))
    
    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)

def list_guests(category):
    guests = get_guests()
    listing = []
    
    for guest in guests:
        list_item = xbmcgui.ListItem(label=guest["title"])
        list_item.setInfo("video", {"title": guest["title"]})
        list_item.setProperty("isPlayable", "false")
        url = "{0}?action=open_guest&link={1}".format(__url__, guest['link'])
        is_folder = True
        listing.append((url, list_item, is_folder))
    
    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)

def list_guest(url):
    episodes = get_guest_episodes(url)
    listing = []
    
    for episode in episodes:
        list_item = xbmcgui.ListItem(label=episode["title"])
        list_item.setArt({"thumb": episode["thumbnail_image"]})
        list_item.setInfo("video", {"title": episode["title"]})
        list_item.setProperty("isPlayable", "false")
        url = "{0}?action=open&link={1}".format(__url__, episode['link'])
        is_folder = True
        listing.append((url, list_item, is_folder))
    
    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)

def exists(url):
    r = requests.head(url)
    return r.status_code == requests.codes.ok

def list_episode(url):
    episode = get_episode(url)
    listing = []

    # thumbnail_image = SITE_EPISODE_THUMBNAIL + episode['number'] + '.jpg'

    # if not exists(thumbnail_image):
    #     thumbnail_image = SITE_EPISODE_THUMBNAIL + episode['number'] + '_temp.jpg'

    i = 0
    for link in episode['links']:
        list_item = xbmcgui.ListItem(label=episode["host"][i])
        list_item.setArt({"thumb": episode["thumbnail_image"]})
        list_item.setInfo("video", {"title": episode["title"], "plot": episode['title']})
        list_item.setProperty("isPlayable", "true")
        url = "{0}?action=play&link={1}".format(__url__, link)
        is_folder = False
        listing.append((url, list_item, is_folder))
        i+=1
    
    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)

def play_episode(path):
    hmf = resolveurl.HostedMediaFile(path).resolve()
    play_item = xbmcgui.ListItem(path=hmf)
    
    xbmcplugin.setResolvedUrl(__handle__, True, listitem=play_item)

def router(paramstring):
    params = dict(parse_qsl(paramstring[1:]))
 
    if params:
        if params['action'] == 'listing':
            get_listing(params['category'])
        elif params['action'] == 'open':
            list_episode(params['link'])
        elif params['action'] == 'open_tag':
            list_tag(params['link'])
        elif params['action'] == 'open_next_page':
            list_tag(params['link'])
        elif params['action'] == 'open_guest':
            list_guest(params['link'])
        elif params['action'] == 'play':
            play_episode(params['link'])
    else:
        list_categories()

if __name__ == "__main__":
    router(sys.argv[2])